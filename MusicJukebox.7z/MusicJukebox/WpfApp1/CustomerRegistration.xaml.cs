﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MusicSystemBL;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for CustomerRegistration.xaml
    /// </summary>
    public partial class CustomerRegistration : Window
    {
        public CustomerRegistration()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer
            {
                CustomerID = int.Parse(textBox.Text),
                CustName = textBox1.Text,
                Address = textBox2.Text,
                DOB = DateTime.Parse(textBox3.Text),
                City = textBox4.Text,
                Password = passwordBox.Password.ToString(),
                MobileNo=textBox5.Text
            };
            customer.AddCustomer(customer);
            MessageBox.Show("New Customer Added");
        }
    }
}
