﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MusicSystemBL;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for Update.xaml
    /// </summary>
    public partial class Update : Window
    {
        public Update()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer
            {
                CustomerID = int.Parse(textBox.Text)
            };
            if (customer.SearchCustomer(customer))
            {
                label.Visibility = Visibility.Visible;
                label1.Visibility = Visibility.Visible;
                label2.Visibility = Visibility.Visible;
                label3.Visibility = Visibility.Visible;
                label4.Visibility = Visibility.Visible;
                label5.Visibility = Visibility.Visible;
                label6.Visibility = Visibility.Visible;
                textBox1.Visibility = Visibility.Visible;
                textBox2.Visibility = Visibility.Visible;
                textBox3.Visibility = Visibility.Visible;
                textBox4.Visibility = Visibility.Visible;
                textBox5.Visibility = Visibility.Visible;
                textBox6.Visibility = Visibility.Visible;
                passwordBox.Visibility = Visibility.Visible;

            }

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Employee employee = new Employee
            {
                EmployeeID = int.Parse(textBox7.Text)
            };
            if (employee.SearchEmployee(employee))
            {
                label7.Visibility = Visibility.Visible;
                label8.Visibility = Visibility.Visible;
                label9.Visibility = Visibility.Visible;
                label10.Visibility = Visibility.Visible;
                label11.Visibility = Visibility.Visible;
                label12.Visibility = Visibility.Visible;
                label13.Visibility = Visibility.Visible;
                textBox8.Visibility = Visibility.Visible;
                textBox9.Visibility = Visibility.Visible;
                textBox10.Visibility = Visibility.Visible;
                textBox11.Visibility = Visibility.Visible;
                textBox12.Visibility = Visibility.Visible;
                textBox13.Visibility = Visibility.Visible;
                passwordBox1.Visibility = Visibility.Visible;

            }
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Employee employee = new Employee
            {
                EmployeeID = int.Parse(textBox8.Text),
                EmpName = textBox9.Text,
                Address = textBox10.Text,
                DOB = DateTime.Parse(textBox11.Text),
                City=textBox12.Text,
                Password=passwordBox1.Password.ToString(),
                MobileNo=textBox13.Text
            };
            employee.UpdateEmployee(employee);
            MessageBox.Show("Employee data updated");
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Customer customer = new Customer
            {
                CustomerID = int.Parse(textBox1.Text),
                CustName = textBox2.Text,
                Address = textBox3.Text,
                DOB = DateTime.Parse(textBox4.Text),
                City = textBox5.Text,
                Password = passwordBox.Password.ToString(),
                MobileNo = textBox6.Text
            };
            customer.UpdateCustomer(customer);
            MessageBox.Show("Customer data updated");
        }
    }
}

