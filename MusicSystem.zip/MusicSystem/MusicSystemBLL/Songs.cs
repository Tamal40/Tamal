﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MusicSystemBLL
{
    class Songs
    {
        public int SongID { get; set; }
        public string SongName { get; set; }
        public string Singer { get; set; }
        public string Movie { get; set; }
        public string ComposedBy { get; set; }
        public string Lyrics { get; set; }
        public int Year { get; set; }
        public int AlbumID { get; set; }
        public string Language { get; set; }
    }
}
